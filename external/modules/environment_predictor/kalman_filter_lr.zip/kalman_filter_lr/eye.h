/*
 * File: eye.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-May-2015 22:19:16
 */

#ifndef __EYE_H__
#define __EYE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "kalman_filter_lr_types.h"

/* Function Declarations */
extern void eye(double varargin_1, emxArray_real_T *I);

#endif

/*
 * File trailer for eye.h
 *
 * [EOF]
 */
