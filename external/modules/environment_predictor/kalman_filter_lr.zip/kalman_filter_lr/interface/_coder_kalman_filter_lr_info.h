/* 
 * File: _coder_kalman_filter_lr_info.h 
 *  
 * MATLAB Coder version            : 2.7 
 * C/C++ source code generated on  : 27-May-2015 22:19:16 
 */

#ifndef ___CODER_KALMAN_FILTER_LR_INFO_H__
#define ___CODER_KALMAN_FILTER_LR_INFO_H__
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* 
 * File trailer for _coder_kalman_filter_lr_info.h 
 *  
 * [EOF] 
 */
