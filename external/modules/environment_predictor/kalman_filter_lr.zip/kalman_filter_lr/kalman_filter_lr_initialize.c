/*
 * File: kalman_filter_lr_initialize.c
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-May-2015 22:19:16
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "kalman_filter_lr.h"
#include "kalman_filter_lr_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void kalman_filter_lr_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for kalman_filter_lr_initialize.c
 *
 * [EOF]
 */
