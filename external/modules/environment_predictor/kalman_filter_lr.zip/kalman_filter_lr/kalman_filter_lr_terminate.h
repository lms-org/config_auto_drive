/*
 * File: kalman_filter_lr_terminate.h
 *
 * MATLAB Coder version            : 2.7
 * C/C++ source code generated on  : 27-May-2015 22:19:16
 */

#ifndef __KALMAN_FILTER_LR_TERMINATE_H__
#define __KALMAN_FILTER_LR_TERMINATE_H__

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "kalman_filter_lr_types.h"

/* Function Declarations */
extern void kalman_filter_lr_terminate(void);

#endif

/*
 * File trailer for kalman_filter_lr_terminate.h
 *
 * [EOF]
 */
